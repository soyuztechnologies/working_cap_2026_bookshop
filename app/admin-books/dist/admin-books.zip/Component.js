sap.ui.define(["sap/fe/core/AppComponent"],o=>o.extend("bookshop.admin-books.Component",{metadata:{manifest:"json"}}));
//# sourceMappingURL=Component.js.map