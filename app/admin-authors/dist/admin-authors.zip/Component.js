sap.ui.define(["sap/fe/core/AppComponent"],e=>e.extend("bookshop.admin-authors.Component",{metadata:{manifest:"json"}}));
//# sourceMappingURL=Component.js.map