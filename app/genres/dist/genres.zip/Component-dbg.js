sap.ui.define(["sap/fe/core/AppComponent"], ac => ac.extend("bookshop.genres.Component", {
  metadata:{ manifest:'json' }
}))
