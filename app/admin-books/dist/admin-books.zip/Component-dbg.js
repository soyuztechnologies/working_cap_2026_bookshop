sap.ui.define(["sap/fe/core/AppComponent"], ac => ac.extend("bookshop.admin-books.Component", {
  metadata:{ manifest:'json' }
}))
