sap.ui.define(["sap/fe/core/AppComponent"], ac => ac.extend("bookshop.admin-authors.Component", {
  metadata:{ manifest: 'json' }
}))
